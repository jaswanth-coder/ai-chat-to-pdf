/**
 * ChatGPT Adapter for chatgpt.com & chat.openai.com
 * Handles user prompts, uploaded screenshots/images, assistant answers, code, and KaTeX equations.
 */
class ChatGPTAdapter extends BaseAdapter {
  constructor() {
    super('ChatGPT');
  }

  isMatching() {
    const host = window.location.hostname;
    return host === 'chatgpt.com' || host === 'chat.openai.com' || host.endsWith('.chatgpt.com');
  }

  getChatTitle() {
    const titleBtn = document.querySelector('button[data-testid*="conversation-title"], header h1, [data-testid="chat-title"]');
    if (titleBtn && titleBtn.textContent.trim()) {
      return titleBtn.textContent.trim();
    }

    let title = document.title || 'ChatGPT Conversation';
    title = title.replace(/\s*-\s*ChatGPT$/i, '').trim();
    return title || 'ChatGPT Conversation';
  }

  /**
   * Dual-pass turn detector: guarantees finding both user prompts AND assistant responses
   */
  getMessageElements() {
    // Collect all conversation turns, articles, and role nodes
    const nodes = Array.from(document.querySelectorAll(
      '[data-testid^="conversation-turn"], article, [data-message-author-role], [class*="user-message"]'
    ));

    const candidateSet = new Set();
    nodes.forEach(el => {
      const parentTurn = el.closest('[data-testid^="conversation-turn"]') || el.closest('article') || el;
      candidateSet.add(parentTurn);
    });

    return Array.from(candidateSet).sort((a, b) => (a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1));
  }

  /**
   * Robust turn data extractor
   */
  extractMessageData(element) {
    // Extract turn index from testid if available (e.g. conversation-turn-4 -> 4)
    const testId = element.getAttribute('data-testid') || element.closest('[data-testid]')?.getAttribute('data-testid') || '';
    const match = testId.match(/conversation-turn-(\d+)/);
    let turnIndex = match ? parseInt(match[1], 10) : -1;

    // Detect role (user vs assistant)
    let role = 'assistant';
    const roleAttr = element.getAttribute('data-message-author-role');
    const userChild = element.querySelector('[data-message-author-role="user"], [class*="user-message"], [data-testid*="user"], [class*="human"]');
    const assistantChild = element.querySelector('[data-message-author-role="assistant"]');
    const hasUserImage = (element.querySelector('img, [class*="attachment" i], button[aria-label*="image" i]') !== null) && 
                         !element.querySelector('.markdown, .prose, [data-message-author-role="assistant"]');

    if (roleAttr === 'user' || userChild || hasUserImage) {
      role = 'user';
    } else if (roleAttr === 'assistant' || assistantChild) {
      role = 'assistant';
    } else if (element.querySelector('.markdown, .prose') && !element.querySelector('[data-message-author-role="user"]')) {
      role = 'assistant';
    } else if (turnIndex !== -1) {
      // Even turns are user, odd turns are assistant in ChatGPT turn indexing
      role = (turnIndex % 2 === 0) ? 'user' : 'assistant';
    }

    const isUser = role === 'user';
    const authorName = isUser ? 'You' : 'ChatGPT';

    // Content element
    let contentElement = element;
    if (!isUser) {
      contentElement = element.querySelector('.markdown') || 
                       element.querySelector('.prose') || 
                       element.querySelector('[data-message-author-role="assistant"]') || 
                       element;
    }

    // Pre-harvest clean HTML string so it survives React DOM unmounting
    let contentHtml = '';
    if (window.ChatPdfUtils && window.ChatPdfUtils.cleanCloneForPrint) {
      const cleanNode = window.ChatPdfUtils.cleanCloneForPrint(contentElement);
      contentHtml = cleanNode ? cleanNode.innerHTML : '';
    }

    // Extract plain text snippet for index display (including image labels)
    let text = '';
    if (contentElement) {
      text = (contentElement.innerText || contentElement.textContent || '').replace(/\s+/g, ' ').trim();
      const imgs = (contentElement || element).querySelectorAll('img');
      if (imgs.length > 0) {
        const imgDetails = Array.from(imgs).map(img => img.alt || img.title || '').filter(Boolean);
        const imgLabel = imgDetails.length > 0 
          ? `🖼️ [Image: ${imgDetails.join(', ').slice(0, 50)}]` 
          : `🖼️ [${imgs.length > 1 ? imgs.length + ' Images' : 'Attached Image'}]`;
        text = text ? `${imgLabel} ${text}` : imgLabel;
      }
    }

    // Stable ID to survive virtual scroll DOM recycling
    let id = element.dataset.chatPdfId;
    if (!id) {
      if (match) {
        id = `turn-${match[1]}`;
      } else {
        id = window.ChatPdfUtils ? window.ChatPdfUtils.getStableId(element, 'chatgpt', role, text) : `turn-${Date.now()}`;
      }
      element.dataset.chatPdfId = id;
    }

    return {
      id,
      turnIndex: turnIndex >= 0 ? turnIndex : 0,
      role,
      authorName,
      text,
      contentElement,
      contentHtml,
      timestamp: window.ChatPdfUtils ? window.ChatPdfUtils.formatDate() : new Date().toLocaleDateString()
    };
  }
}

window.ChatGPTAdapter = ChatGPTAdapter;
